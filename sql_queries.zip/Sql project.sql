1.Posa katalimata iparxoun

SELECT COUNT(*) AS total_listings FROM listings_cleansed

2. Poses axiologiseis exoun ginei

SELECT COUNT(*) AS total_reviews FROM reviews;


3. Poses kratiseis exoun ginei( Prepei to available na einai iso me 0)

SELECT COUNT(*) AS total_reservations
FROM calendar
WHERE available = 0

4.Posoi monadikoi oikodespotes iparxoun

SELECT COUNT(DISTINCT host_id) AS unique_hosts FROM listings_cleansed;


5. Poies einai oi monadikes perioxes pou prosferontai ta katalimata

SELECT DISTINCT neighbourhood_cleansed FROM listings_cleansed;

6.Poio einai to pososto katalimatwn ana perioxh 

SELECT neighbourhood_cleansed, 
COUNT(*) AS total_listings, 
ROUND(CAST(COUNT(*) AS FLOAT) / (SELECT COUNT(*) FROM listings_cleansed) * 100, 2) AS percentage
FROM listings_cleansed
GROUP BY neighbourhood_cleansed
ORDER BY percentage DESC;

7.Poioi oikodespotes (superhost/non=superhost) exoun ta perissotera katalimata 

SELECT  host_is_superhost, 
COUNT(*) AS total_listings
FROM listings_cleansed
GROUP BY host_is_superhost
ORDER BY total_listings DESC;

8.Posa katalimata exei o kathe oikodespotis (na ferete to onoma tou)

SELECT host_name, COUNT(*) AS name_host
FROM listings_cleansed
GROUP BY host_name


9.Antliste ta katalimata twn opoiwn h perioxh pou vriskontai ksekina apo P 
SELECT * 
FROM listings_cleansed
WHERE neighbourhood_cleansed LIKE '�%';

10.Antliste ta katalimata twn opoiwn h timh einai metaxi 0 kai 100

SELECT * 
FROM listings_cleansed
WHERE price BETWEEN 0 AND 100;


11. Poia katalimata den exoun kamia axiologhsh

SELECT id
FROM listings_cleansed
WHERE id NOT IN (
    SELECT DISTINCT listing_id
    FROM reviews);


12. Posoi oikodespotes exoun photografia profile

SELECT COUNT(host_id) AS hosts_with_pic
FROM listings_cleansed
WHERE host_has_profile_pic = 1;

13. Poia einai h mesh timh ana perioxh 

SELECT  neighbourhood_cleansed , AVG(price) AS avg_price
FROM listings_cleansed
GROUP BY  neighbourhood_cleansed ;

14. Poios tipos property exei thn megaliterh mesh timh (Kratiste akrivws ton prwto)
SELECT TOP 1 property_type, AVG(price) AS avg_price
FROM listings_cleansed
GROUP BY property_type
ORDER BY avg_price DESC;

15.Poies perioxes exoun mesh timh megaluterh apo 200 evrw ana vradia 

SELECT neighbourhood_cleansed
FROM listings_cleansed
GROUP BY neighbourhood_cleansed
HAVING AVG(price) > 200;

16. Poses kratiseis exoun ginei ana typo property (Gia na exei ginei krathsh ena katalima, prepei na exei toulaxiston mia eggrafh sto calendar me available =0 )

SELECT property_type, COUNT(calendar.listing_id) AS total_reservations_per_property_type
FROM listings_cleansed
JOIN calendar ON listings_cleansed.id= calendar.listing_id
Where available= 0
GROUP BY property_type;

17. Poios einai o typos dwmatiou me tis perissoteres axiologiseis 

SELECT a.room_type, COUNT(b.id) AS total_reviews
FROM listings_cleansed a
JOIN reviews b ON a.id = b.listing_id
GROUP BY a.room_type
ORDER BY total_reviews DESC


Allaxte to data type olwn twn sthlwn pou exoun times t/f 
Kante update oles tis sthles pou einai t/f se Yes/No.


ALTER TABLE listings_cleansed
ALTER COLUMN has_availability VARCHAR(3);

UPDATE listings_cleansed
SET has_availability =CASE 
 WHEN has_availability = 't' THEN 'Yes'
  WHEN has_availability = 'f' THEN 'No'  END
               

ALTER TABLE listings_cleansed
ALTER COLUMN host_has_profile_pic VARCHAR(3);


UPDATE listings_cleansed
SET host_has_profile_pic =CASE 
 WHEN host_has_profile_pic = 't' THEN 'Yes'
  WHEN host_has_profile_pic = 'f' THEN 'No'END

  
ALTER TABLE listings_cleansed
ALTER COLUMN host_is_superhost VARCHAR(3);



UPDATE listings_cleansed
SET  host_is_superhost =CASE 
 WHEN  host_is_superhost = 't' THEN 'Yes'
  WHEN  host_is_superhost = 'f' THEN 'No'END
               
 
   
ALTER TABLE listings_cleansed
ALTER COLUMN has_availability VARCHAR(3);


UPDATE listings_cleansed
SET  has_availability =CASE 
 WHEN  has_availability = 't' THEN 'Yes'
  WHEN  has_availability = 'f' THEN 'No'END


  
ALTER TABLE listings_cleansed
ALTER COLUMN instant_bookable VARCHAR(3);

UPDATE listings_cleansed
SET  instant_bookable =CASE 
 WHEN  instant_bookable = 't' THEN 'Yes'
  WHEN  instant_bookable = 'f' THEN 'No'END

 ALTER TABLE calendar
ALTER COLUMN available VARCHAR(3);


UPDATE calendar
SET  available =CASE 
 WHEN  available = 't' THEN 'Yes'
  WHEN  available = 'f' THEN 'No'END